# HYFA Time Reversal — Android project scaffold

A native Android wrapper for a self-contained HTML/CSS/JavaScript mentalism experience, plus a real Android home-screen clock widget.

## Architecture

- `app/src/main/java/com/hyfa/timereversal/MainActivity.kt` — native activity hosting the local web interface in a WebView.
- `app/src/main/java/com/hyfa/timereversal/widget/HyfaWidget.kt` — Android home-screen widget implemented with Jetpack Glance; tapping it opens the app.
- `app/src/main/res/xml/hyfa_widget_info.xml` — widget size and host metadata.
- `app/src/main/assets/index.html` — spectator-facing performance UI and performer controls.
- `app/src/main/assets/css/app.css` — dark violet/cyan visual theme and animations.
- `app/src/main/assets/js/app.js` — clock display, reverse-time animation, swipe gesture, tap interaction, and staged reveal.

## Build in Android Studio

1. Install Android Studio with Android SDK 35 and a compatible JDK (17 recommended).
2. Open this folder as an existing Gradle project.
3. Allow Gradle to sync and download dependencies.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the APK on an Android device.
6. Long-press an empty area of the home screen, choose **Widgets**, find **HYFA Time Reversal**, and place the widget.

This source scaffold does not include a Gradle wrapper or a prebuilt APK. Android Studio can generate/use a local Gradle installation. Dependency resolution requires internet access on the first build.

## FreeWebToAPK option

If using FreeWebToAPK only, upload the contents of `app/src/main/assets/` as the web app files (make `index.html` the entry page). This gives you the in-app web experience only. It does **not** install the Kotlin widget. To include the real Android home-screen widget, build the full Android project above or use a custom native wrapper that includes this web UI and widget.

## Gestures and performance flow

- Swipe right-to-left on the interaction field: plays a staged backward clock animation and reveal.
- Tap the clock: performer-control entry gesture is included as a starter hook; tune the sequence in `app.js` before a live performance.
- The top-right control opens the private settings panel for development/testing.
- The clock shown is a visual performance clock. The app does not modify Android's actual system time.

## Before public release

- Test the widget on multiple launchers and Android versions.
- Review Android Studio compile output and resolve any dependency/API differences for your installed SDK versions.
- Replace or further harden the demo performer-control entry method before handing the phone to a spectator. A visible settings icon is intentionally retained as a development fallback.
- Add an app icon, screenshots, accessibility labels, and privacy disclosures as needed.

## Project status

This is a source project starter, not a verified compiled release. The code has not been built or tested on a physical device in this environment.
