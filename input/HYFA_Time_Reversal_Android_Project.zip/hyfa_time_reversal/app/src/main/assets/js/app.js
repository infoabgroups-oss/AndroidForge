(() => {
  const $ = id => document.getElementById(id);
  const clock = $('clock'), status = $('status'), prediction = $('prediction'), hint = $('predictionHint');
  let reversing = false, tapCount = 0, tapTimer = null, secretSequence = '3-1-3';
  let revealMessage = 'You were thinking of this moment.', targetTime = '11:11';
  const pad = n => String(n).padStart(2, '0');
  function renderClock() {
    const d = new Date();
    if (!reversing) clock.textContent = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
    $('dateLine').textContent = d.toLocaleDateString(undefined, {weekday:'long', month:'long', day:'numeric'}).toUpperCase();
  }
  setInterval(renderClock, 1000); renderClock();
  function startReverse() {
    if (reversing) return;
    reversing = true; document.body.classList.add('reversing'); $('modeLabel').textContent = 'REVERSING';
    status.textContent = 'The last few seconds are slipping away…';
    prediction.textContent = 'Returning to the chosen moment'; hint.textContent = 'Watch the clock. Remember the number.';
    let step = 0, now = new Date();
    const initial = now.getHours()*3600 + now.getMinutes()*60 + now.getSeconds();
    const interval = setInterval(() => {
      step++;
      let s = (initial - step*3 + 86400) % 86400;
      clock.textContent = `${pad(Math.floor(s/3600))}:${pad(Math.floor(s%3600/60))}:${pad(s%60)}`;
      if (step >= 12) {
        clearInterval(interval); reversing = false; document.body.classList.remove('reversing');
        $('modeLabel').textContent = 'REVEAL'; status.textContent = 'Time has returned to the present.';
        prediction.textContent = targetTime; hint.textContent = 'The moment you were asked to remember.';
        $('revealHeading').textContent = 'The moment remembers.'; $('revealBody').textContent = revealMessage;
        $('revealOverlay').classList.remove('hidden'); renderClock();
      }
    }, 160);
  }
  $('reverseBtn').addEventListener('click', startReverse);
  $('resetBtn').addEventListener('click', () => { reversing = false; document.body.classList.remove('reversing'); $('modeLabel').textContent='READY'; status.textContent='Focus on a moment. Hold it in your mind.'; prediction.textContent='A moment is waiting.'; hint.textContent='Choose a moment, then let time return.'; renderClock(); });
  let startX = null;
  const padEl = $('gesturePad');
  padEl.addEventListener('touchstart', e => { startX = e.changedTouches[0].clientX; }, {passive:true});
  padEl.addEventListener('touchend', e => { if (startX !== null && startX - e.changedTouches[0].clientX > 45) startReverse(); startX = null; }, {passive:true});
  padEl.addEventListener('mousedown', e => { startX = e.clientX; });
  padEl.addEventListener('mouseup', e => { if (startX !== null && startX - e.clientX > 45) startReverse(); startX = null; });
  // Hidden performer sequence: tap the clock in the configured rhythm.
  clock.addEventListener('click', () => {
    tapCount++;
    clearTimeout(tapTimer);
    tapTimer = setTimeout(() => { tapCount = 0; }, 1600);
    const expected = secretSequence.split('-').map(Number);
    // Each tap is separated by a short pause; matching the sequence opens controls.
    if (tapCount >= expected.reduce((a,b)=>a+b,0)) { tapCount = 0; openPanel(); }
  });
  function openPanel(){ $('performerPanel').classList.remove('hidden'); $('targetTime').value = targetTime; $('revealText').value = revealMessage; $('secretCode').value = secretSequence; }
  $('settingsToggle').addEventListener('click', openPanel);
  $('closePanel').addEventListener('click', () => $('performerPanel').classList.add('hidden'));
  $('clearSettings').addEventListener('click', () => $('performerPanel').classList.add('hidden'));
  $('saveSettings').addEventListener('click', () => {
    targetTime = $('targetTime').value || '11:11'; revealMessage = $('revealText').value.trim() || 'You were thinking of this moment.'; secretSequence = $('secretCode').value;
    $('performerPanel').classList.add('hidden'); status.textContent = 'Performance settings saved.';
  });
  $('dismissReveal').addEventListener('click', () => $('revealOverlay').classList.add('hidden'));
  $('revealOverlay').addEventListener('click', e => { if(e.target === $('revealOverlay')) $('revealOverlay').classList.add('hidden'); });
})();
