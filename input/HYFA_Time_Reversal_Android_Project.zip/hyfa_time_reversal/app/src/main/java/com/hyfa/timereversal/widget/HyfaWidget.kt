package com.hyfa.timereversal.widget

import android.content.Context
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.compose.ui.graphics.Color
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.glance.unit.dp
import com.hyfa.timereversal.MainActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HyfaWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val date = SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(Date())
        provideContent {
            Column(
                modifier = GlanceModifier.fillMaxSize()
                    .background(ColorProvider(Color(0xFF101020)))
                    .clickable(actionStartActivity<MainActivity>())
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("HYFA  •  TIME FIELD", style = TextStyle(color = ColorProvider(Color(0xFFB9A5FF))))
                Text(time, style = TextStyle(color = ColorProvider(Color(0xFFFFFFFF))))
                Text("$date  ·  Tap to reverse", style = TextStyle(color = ColorProvider(Color(0xFFB9B8CA))))
            }
        }
    }
}

class HyfaWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = HyfaWidget()
}
